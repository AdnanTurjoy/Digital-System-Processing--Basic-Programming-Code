#include<bits/stdc++.h>
using namespace std;
int main()
{
   int n1,i,j;

   cout<< "Enter  Number of element of array = : "<<endl;
   cin>>n1;

   int x1[n1];
   int t;
   double re1[n1];
   cout<<"Enter the array elements: "<<endl;
   for(i=0;i<n1;i++)
   {
       cin>>x1[i];
   }
   cout<<"Enter the impulse signal = "<<endl;
   cin>>t;

for(i=0;i<n1;i++)
   {
       re1[i]=(double)(t-x1[i])/t;
   }
   cout<<"The result: "<<endl;
for(i=0;i<n1;i++)
   {
       cout<<re1[i]<<" ";
   }
return 0;

}

